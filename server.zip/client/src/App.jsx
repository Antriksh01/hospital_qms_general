
// import Header from "./component/Header";
import Homepage from "./component/Homepage";
import Tokengenerated from "./component/Tokengenerated";
// import Registerpage from "./component/Registerpage";


function App() {
  return (
    <>
      {/* <Homepage /> */}
      {/* <Header/> */}
      {/* <Registerpage/> */}
      <Tokengenerated/>
    </>
  );
}

export default App;
