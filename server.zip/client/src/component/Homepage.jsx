import React from "react";
// import Tokengenerated from "./Tokengenerated";
// import Frontpage from "./Frontpage";
// import Displayscreen from "./Displayscreen";
// import Managereceptionist from "./Managereceptionist";
// import Managedoctor from "./Managedoctor";
// import Admindashboard from "./Admindashboard";
// import DisplayContent from "./Displaycontent";
import Doctordashboard from "./Doctordashboard";
// import Registerapatient from "./Registerapatient";
// import Dashboard from "./Dashboard";
// import Reports from "./Reports";
// import DoctorTreatment from "./Doctortreatment";



const Homepage = () => {
  return (
<>
  {/* <Registerapatient /> */}
  <Doctordashboard/>

  {/* <Reports/> */}
  {/* <Dashboard/> */}
  {/* <Admindashboard/> */}
  {/* <DisplayContent/> */}
  {/* <Managedoctor/> */}
  {/* <Managereceptionist/> */}
  {/* <DoctorTreatment/> */}
  {/* <Displayscreen/> */}
  {/* <Frontpage/> */}
  {/* <Tokengenerated/> */}
  {/* <Registerpage/> */}
  </>
  )
  
};

export default Homepage;
