import React from "react";

const RecDashboard = () => {
  return <div>RecDashboard</div>;
};

export default RecDashboard;
